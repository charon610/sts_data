package com.spring.pboard.vo;

import lombok.Data;

@Data
public class PBoardVo {
	private int idx;
	private String title; 
	private String mem_id;
	private String img_url;
	private String cont;
	private String regdate;
	
	
	
}
