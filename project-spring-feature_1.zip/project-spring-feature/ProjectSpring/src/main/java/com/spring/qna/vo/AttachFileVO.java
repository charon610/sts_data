package com.spring.qna.vo;

import lombok.Data;

@Data
public class AttachFileVO {

	private String a_filename;
	private String a_savepath;
	private String a_uuid;
	private boolean a_isimage;
	
}