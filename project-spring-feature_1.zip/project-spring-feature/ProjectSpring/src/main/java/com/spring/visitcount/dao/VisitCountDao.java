package com.spring.visitcount.dao;

public interface VisitCountDao {

	void setVisitTotalCount();

	int getVisitTodayCount();

	int getVisitTotalCount();
	
}
